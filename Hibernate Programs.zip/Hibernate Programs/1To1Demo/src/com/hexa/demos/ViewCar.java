package com.hexa.demos;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.hexa.entity.Car;

public class ViewCar {
	
public static void main(String[] args) {
	Configuration cfg = new AnnotationConfiguration();
	cfg.configure();//loads hiberate.cfg.xml
	SessionFactory sfac = cfg.buildSessionFactory();
	 Session sess = sfac.openSession();
	 Car car =(Car)sess.get(Car.class, 1);
	 System.out.println(car.getCarId()+" "+car.getCarName()+" "+car.getPrice()+" "+
	 car.getChasis().getChasisId()+" "+car.getChasis().getChasisType());
}
}
