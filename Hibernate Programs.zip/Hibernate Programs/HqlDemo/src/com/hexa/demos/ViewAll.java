package com.hexa.demos;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.hexa.entity.Student;

public class ViewAll {

	public static void main(String[] args) {
		Configuration cfg = new AnnotationConfiguration();
		cfg.configure();//loads hiberate.cfg.xml
		SessionFactory sfac = cfg.buildSessionFactory();
		Session sess = sfac.openSession();
		 //HQL query to receive all the datas
		 //String hql = "from Student ";
		String hql = "from Student  order by marks desc";// query displaying the marks desc
		 Query qry = sess.createQuery(hql);
		 List<Student> lst =qry.list();
		 sess.close();
		 lst.stream().forEach(System.out::println);

	}

}
