package com.hexa.demos;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class AggDemo {

	public static void main(String[] args) {
		Configuration cfg = new AnnotationConfiguration();
		cfg.configure();//loads hiberate.cfg.xml
		SessionFactory sfac = cfg.buildSessionFactory();
		Session sess = sfac.openSession();
		// sum , avg, min and max of marks
		String hql = "select sum(marks),avg(marks),max(marks),min(marks) from Student";
		 Query qry = sess.createQuery(hql);
		 Object[] lst = (Object[])qry.uniqueResult(); // because it return on single row output
		 sess.close();
		 System.out.println(lst[0]);
		 System.out.println(lst[1]);
		 System.out.println(lst[2]);
		 System.out.println(lst[3]);
	}

}
