package com.hexa.demos;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hexa.dao.DaoImp1;
import com.hexa.dao.IDao;
import com.hexa.entity.Student;

public class Updatemarks2 {

	public static void main(String[] args) {
		
		IDao dao = new DaoImp1();
		Student stu = dao.getStudent( 1001);
		stu.setMarks(122);
		dao.updateStudent(stu);
		System.out.println("updated");
	}

}
