package com.hexa.demos;

import com.hexa.dao.DaoImp1;
import com.hexa.dao.IDao;

public class DeleteStudent {

	public static void main(String[] args) {
		IDao dao = new DaoImp1();
		int res = dao.deleteStudent(1001);
		System.out.println("deleted");

	}

}
