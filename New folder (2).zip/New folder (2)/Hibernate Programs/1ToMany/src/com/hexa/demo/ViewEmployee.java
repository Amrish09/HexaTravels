package com.hexa.demo;

import java.util.Set;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.hexa.entity.Dept;
import com.hexa.entity.Emp;

public class ViewEmployee {
	private static SessionFactory sfac;
	static {
		Configuration cfg = new AnnotationConfiguration();
		cfg.configure();//loads hiberate.cfg.xml
		 sfac = cfg.buildSessionFactory();
	}
	public static void main(String[] args) {
		Session sess = sfac.openSession();
		Emp emp =(Emp)sess.get(Emp.class,1001);// get only emp details
		sess.close();
		System.out.println(emp.getEmpId()+""+emp.getEmpName()+""+emp.getPwd()+""+emp.getSal()+""+emp.getImg()+""+emp.getDept().getDeptName());//it will get depts dept() so we shld use this emp.getDept().getDeptName()

}
}
