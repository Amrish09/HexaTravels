package com.hexa.demo;

import java.util.Set;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.hexa.entity.Dept;
import com.hexa.entity.Emp;

public class ViewDeptNEmp {
	//config outside the class
	private static SessionFactory sfac;
	static {
		Configuration cfg = new AnnotationConfiguration();
		cfg.configure();//loads hiberate.cfg.xml
		 sfac = cfg.buildSessionFactory();
	}

	public static void main(String[] args) {
		
		
		Dept dept = getDept(1);
		System.out.println(dept.getDeptId()+""+dept.getDeptName());// it displays dept details
		Set<Emp> set = dept.getElist();// it throws query in this line
		System.out.println("======================================");
		for(Emp emp:set) {// now it will retrive the values when it uses the class entity
			System.out.println(emp.getEmpId()+""+emp.getEmpName()+""+emp.getPwd()+""+emp.getSal()+""+emp.getImg()+""+emp.getDept());// here it can't get the values
		}

	}
	public static Dept getDept(int id) {
		Session sess = sfac.openSession();
		Dept dept =(Dept)sess.get(Dept.class,1);// get only dept details
		Hibernate.initialize(dept.getElist());// it also fetches the employee details
		sess.close();
		return dept;// return dept details
		
		
	}

}
