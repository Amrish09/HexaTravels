package com.hexa.demos;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.hexa.entity.Student;

public class DetachedDemo {

	private static SessionFactory sfac;
	static {
		Configuration cfg = new AnnotationConfiguration();
		cfg.configure();//loads hiberate.cfg.xml
		 sfac= cfg.buildSessionFactory();
	}
	public static void main(String[] args) {
		Student stu = getStudent(1003);
		Session sess = sfac.openSession();
		Transaction tx = sess.beginTransaction();
		stu.setMarks(190);
		sess.update(stu);// here we are making the session object from detached to persistance by update() or saveupdate()
		tx.commit();
		sess.close();
		System.out.println("done");
		
	}
 public static Student getStudent(int sid) {
	 Session sess = sfac.openSession();
	 Student stu = (Student)sess.get(Student.class, sid);
	 sess.close();// here student becomes detached state
	return stu;
	 
 }
}
