package com.hexa.demos;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.hexa.dao.DaoImp1;
import com.hexa.dao.IDao;
import com.hexa.entity.Student;

public class InsertEmployee {
	private static IDao dao = new DaoImp1();
	public static void main(String[] args) throws Exception  {
	    Student stu = new Student();
	    stu.setStuId(1001);
	    stu.setStName("durga");
	    stu.setDept("ECE");
	    stu.setMarks(75);
	    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	    Date dt = sdf.parse("12/04/1995");
	    stu.setDob(dt);
	    stu.setStuId(1002);
	    stu.setStName("devi");
	    stu.setDept("EEE");
	    stu.setMarks(95);
	    SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
	    Date dt1 = sdf1.parse("12/04/1995");
	    stu.setDob(dt1);
	    int res1 = dao.addStudent(stu);
	    stu.setStuId(1003);
	    stu.setStName("nisha");
	    stu.setDept("CSE");
	    stu.setMarks(100);
	    SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
	    Date dt2 = sdf2.parse("12/04/1995");
	    stu.setDob(dt2);
	    int res2 = dao.addStudent(stu);
	    stu.setStuId(1004);
	    stu.setStName("saras");
	    stu.setDept("IT");
	    stu.setMarks(90);
	    SimpleDateFormat sdf3 = new SimpleDateFormat("dd/MM/yyyy");
	    Date dt3 = sdf3.parse("12/04/1995");
	    stu.setDob(dt3);
	    int res3 = dao.addStudent(stu);
		System.out.println("table created");
	}

}
