package com.hexa.demos;

import com.hexa.dao.DaoImp1;
import com.hexa.dao.IDao;

public class UpdateMarks {

	public static void main(String[] args) {
		IDao dao = new DaoImp1();
		int res = dao.updateStudent(1002, 100);
		System.out.println("updated");

	}

}
