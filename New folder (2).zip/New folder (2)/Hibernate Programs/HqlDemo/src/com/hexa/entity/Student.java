package com.hexa.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // to say hibernate that we using java class to map tyhe table
@Table(name="student")//it should map to student table
public class Student {

@Id //specifying the primary key
@Column(name="stu_id")
private int stuId;

@Column(name="stu_name", length=45)
private String StName;

@Column(name="stu_dept", length=10)
private String dept;

@Column(name="stu_dob")
private Date dob;

@Column(name="stu_marks")
private int marks;

public int getStuId() {
	return stuId;
}

@Override
public String toString() {
	return "Student [stuId=" + stuId + ", StName=" + StName + ", dept=" + dept + ", dob=" + dob + ", marks=" + marks
			+ "]";
}

public void setStuId(int stuId) {
	this.stuId = stuId;
}

public String getStName() {
	return StName;
}

public void setStName(String stName) {
	StName = stName;
}

public String getDept() {
	return dept;
}

public void setDept(String dept) {
	this.dept = dept;
}

public Date getDob() {
	return dob;
}

public void setDob(Date dob) {
	this.dob = dob;
}

public int getMarks() {
	return marks;
}

public void setMarks(int marks) {
	this.marks = marks;
}

}
