package com.hexa.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hexa.dao.BusDao;
import com.hexa.dao.InvalidException;
import com.hexa.dao.UserException;
import com.hexa.entity.LoginBean;
import com.hexa.service.BusSer;


@Controller
public class BusController {
	private Logger logger= LoggerFactory.getLogger("bus");
	
	@Autowired
	private BusDao dao;
	
	@Autowired
	private BusSer ser;
	
	//Login page
		@RequestMapping("/Main")
		public String displayMain() {
			return "Main";
		}	
		
	//Login page
	@RequestMapping("/Login")
	public String displayIdFrm(){
		return "LoginPage";
	}
	
	
	@RequestMapping(value="/checkLogin", method=RequestMethod.POST)
	public String checkLogin(HttpServletRequest request,Model model, @RequestParam("uname") Integer uname, @RequestParam("psw") String pwd) {
		HttpSession sess=request.getSession();
		LoginBean lb=dao.checkUser(uname, pwd);
		if(lb==null)
		{
			return "LoginPage";
		}
		sess.setAttribute("log", lb);
		
		return "BusSearch";	
	}
	
	//searching for buses
	@RequestMapping("/search")
	public String  dislpayBusSchedule( Model model) {
		return "BusSearch";
	}
	//getting schedule of bus
	@RequestMapping("/displaySchedule")
	public String  displayBusId(@RequestParam("src") String src,@RequestParam("dest") String dest,@RequestParam("doj") String doj,Model model) throws InvalidException {
		model.addAttribute("dlist", dao.getBusSchedule(src, dest, doj));
		return "BusScheduleDisplay";
	}
	//displaying booking id
	@RequestMapping("/displayBooking")
	public String  displayBookingId(@RequestParam("bid") Integer busid,Model model) {
		model.addAttribute("ilist", dao.getBusDetails(busid));
		return "BusIdDisplay";
	}
	
	//insertion and updating.........
	@RequestMapping("/displayUserBook")
	public String displayUserBook(@RequestParam("noofseatsrequired") Integer seat,@RequestParam("schId") Integer sid ,@RequestParam("uname") Integer lid, Model model) throws UserException {
		model.addAttribute("slist", ser.getBusUpdate(seat,sid, lid));
		model.addAttribute("llist", dao.getUserBookingDetails(lid));
		return "BookingDetailDisplay";
	}
	
	@RequestMapping("/logout")
	public String checkLogin(HttpServletRequest request) {
		HttpSession sess=request.getSession(false);
		sess.invalidate();
		
		return "LoginPage";	
	}
	
	
	
	@ExceptionHandler(InvalidException.class)
	public ModelAndView handleException(InvalidException ex) {
		return new ModelAndView("MyErr","err",ex.getMessage());
	}
	
	@ExceptionHandler(UserException.class)
	public ModelAndView UserException(UserException ex) {
		return new ModelAndView("Error","err",ex.getMessage());
	}
}
	
	
	
	
	

