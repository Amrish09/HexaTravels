begin 
dbms_output.put_line('Welcome to plsql'); 
end;