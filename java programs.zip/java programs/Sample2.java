import java.util.*;
public class Sample2{
public static void main(String[] args)
{
List<Integer> ll =new ArrayList<>();
ll.add(9000);
ll.add(150);
ll.add(300);
System.out.println("Before 8");
Iterator<Integer> li = ll.iterator();
while(li.hasNext()){
System.out.println(li.next());
}
System.out.println("before sort");

ll.forEach((i)->System.out.println(i));
Collections.sort(ll); // method in Collections Class ie methods are static
System.out.println("after sort");
ll.forEach((i)->System.out.println(i));

}
}