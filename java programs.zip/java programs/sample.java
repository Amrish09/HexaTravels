 interface Abc{
public default void dis1(){
System.out.println("dis1 default implementation");
}
void dis2();
public default void dis3(){
System.out.println("dis3 default implementation");
}
}
class X implements Abc{
public void dis2(){
System.out.println("dis2 override");
}
public void dis3(){
System.out.println("dis3 override");
}
}



public class Sample{
public static void main(String[] args)
{
System.out.println("Welcome to java 8");
X x= new X();
x.dis1();
x.dis2();
x.dis3();
}
}
