package com.hexa.service;

import com.hexa.dao.UserException;

public interface BusSer {
	
	int getBusUpdate(int userSeats,int schId,int loginId) throws UserException;
	


}
