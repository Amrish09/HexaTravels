package com.hexa.dao;

import java.util.Date;
import java.util.List;
import java.util.Random;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

import com.hexa.entity.BookingDetailsBean;
import com.hexa.entity.BusDetailsBean;
import com.hexa.entity.BusScheduleBean;
import com.hexa.entity.LoginBean;

@Repository("mydao")
public class BusDaoImpl implements BusDao {
	 private Logger logger = LoggerFactory.getLogger("bus");
		
	 @Autowired
		private SessionFactory sfac;
		
		
		

	

	@Override
	public List<BusScheduleBean> getBusSchedule(String source, String destination, String doj) throws InvalidException  {
		
		logger.debug("Bus Schedule method");
			Session sess = sfac.openSession();
			String hql="from BusScheduleBean bs inner join fetch bs.bdetail bl where bl.source=? and bl.destination=? and bs.dateOfJourney=?";
			 Query qry = sess.createQuery(hql);
			 qry.setString(0, source);
			 qry.setString(1, destination);
			 qry.setString(2, doj);
			 List<BusScheduleBean> lst =qry.list();
			 if(lst.size()==0) {
					logger.error("Notexception raise");
					throw new InvalidException("Source and destination are invalid");
				}
			 sess.close();
			 return lst;		 		 
	}

	@Override
	public List<BusScheduleBean> getBusDetails(int bid) {
		logger.debug("Bus Details method");
		Session sess = sfac.openSession();
		String hql="from BusScheduleBean bd inner join fetch bd.bdetail bsh where bsh.bid=?";
		 Query qry = sess.createQuery(hql);
		 qry.setInteger(0,bid);
		 List<BusScheduleBean> lst =qry.list();
		 sess.close();
		return lst;
	}

	@Override
	public int insertBookId(BookingDetailsBean bd) {
		logger.debug("Insert Book Id");
		Session sess = sfac.getCurrentSession();
		sess.save(bd);
		
		
		return 1;
	}

	@Override
	public int UpdateNoOfSeats(int schId, int noOfSeats) {
		logger.debug("UpdateNoOfSeats method");
		Session sess = sfac.getCurrentSession();
		BusScheduleBean busSch =(BusScheduleBean)sess.get(BusScheduleBean.class, schId);
		busSch.setNoOfSeatsAvailable(noOfSeats);
		sess.update(busSch);
		return 0;
		
	}
	@Override
	public List<BookingDetailsBean> getUserBookingDetails(int loginId) {
		logger.debug("User BookingDeatils method");
		Session sess = sfac.openSession();
		String hql="from BookingDetailsBean b inner join fetch b.login ll where ll.loginId=?";
		Query qry = sess.createQuery(hql);
		 qry.setInteger(0, loginId);
		 List<BookingDetailsBean> lst=qry.list();
		 sess.close();
		 return lst;
	
	}



	@Override
	public BusScheduleBean getSeats(int schId) {
		logger.debug("no of seats booking method");
		Session sess = sfac.openSession();
		String hql="from BusScheduleBean b where b.schId=? ";
		Query qry = sess.createQuery(hql);
		 qry.setInteger(0, schId);
		 BusScheduleBean bd=(BusScheduleBean) qry.uniqueResult();
		 sess.close();
		 return bd;
	}



	@Override
	public int setBookingId() {
		logger.debug("generaring bookingid method");
		Session sess = sfac.openSession();
		String hql="select max(bookingId) from BookingDetailsBean";
		Query qry = sess.createQuery(hql);
		int bookid=(int) qry.uniqueResult();
		sess.close();
        return bookid; 
	}

	@Override
	public double getPrice(int busId) {
		logger.debug("generaring bookingid method");
		Session sess = sfac.openSession();
		String hql="select price from BusDetailsBean where busId=?";
		Query qry = sess.createQuery(hql);
		double price=(double) qry.uniqueResult();
		sess.close();
        return price; 
		
		
	}

	@Override
	public LoginBean checkUser(int loginId, String password){
		logger.debug("checking user method");
		Session sess = sfac.openSession();
		String hql="from LoginBean where loginId=? and password=?";
		Query qry = sess.createQuery(hql);
		qry.setInteger(0, loginId);
		qry.setString(1, password);
		LoginBean lbean=(LoginBean) qry.uniqueResult();
		sess.close();
		if(lbean!=null) {
			logger.error("Username and password is wrong");
			return lbean;
		}
		
		return null;
	}			
}
