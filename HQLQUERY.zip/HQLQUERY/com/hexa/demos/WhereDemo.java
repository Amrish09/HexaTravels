package com.hexa.demos;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.hexa.entity.Student;

public class WhereDemo {

	public static void main(String[] args) {
		Configuration cfg = new AnnotationConfiguration();
		cfg.configure();//loads hiberate.cfg.xml
		SessionFactory sfac = cfg.buildSessionFactory();
		Session sess = sfac.openSession();
		// HQL only takes className and field 
		//eg..CLASSNAME :Student and FIELd :dept(variable name in java bean class)
		// student from given dept
		String hql = "from Student where dept=?";
		 Query qry = sess.createQuery(hql);
		 qry.setString(0, "eee");
		 List<Student> lst =qry.list();
		 sess.close();
		 lst.stream().forEach(System.out::println);

	}

}
